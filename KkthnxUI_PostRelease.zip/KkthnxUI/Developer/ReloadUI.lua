-- Shortcut to ReloadUI

local _G = _G

_G.SLASH_RELOADUI1 = "/rl"
_G.SLASH_RELOADUI2 = "/reloadui"
SlashCmdList.RELOADUI = ReloadUI